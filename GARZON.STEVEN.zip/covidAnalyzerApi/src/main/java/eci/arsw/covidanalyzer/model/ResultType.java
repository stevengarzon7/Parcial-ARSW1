package eci.arsw.covidanalyzer.model;

public enum ResultType {

    TRUE_POSITIVE,
    TRUE_NEGATIVE,
    FALSE_POSITIVE,
    FALSE_NEGATIVE
    
}
